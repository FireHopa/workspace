#!/usr/bin/env python3
"""Entrega 07: start ONLY pre-existing staging Central, Diagnostic and Keycloak.

No Nginx edits, production deployment, key regeneration, global PM2 actions,
or Docker volume deletion. Python >=3.10. Run as deploy, without sudo.
"""
from __future__ import annotations

import argparse
import fcntl
import getpass
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import ssl
import stat
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HOME = Path.home().resolve()
ROOT = HOME / 'plataforma-hml-entrega02'
PREVIOUS = HOME / 'Entrega_06_Troca_Dominio_Workspace' / 'entrega06.py'
PRIVATE = ROOT / 'privado' / 'entrega07'
KEYCLOAK = ROOT / 'privado' / 'entrega03' / 'keycloak'
COMPOSE = KEYCLOAK / 'docker-compose.yml'
PROJECT = 'casadoads_hml_oidc'
VOLUME = 'casadoads_hml_oidc_postgres_data'
NETWORK = 'casadoads_hml_oidc_net'
HOST = 'hml.workspacecasadoads.com.br'
LOGIN = 'login-hml.workspacecasadoads.com.br'
ORIGIN = 'https://' + HOST
ISSUER = 'https://' + LOGIN + '/realms/casadoads-hml'
EXPECTED_IP = '144.91.94.158'  # DNS observed from server on 2026-10-26
REALM = 'casadoads-hml'
CLIENT_ID = 'central-casadoads-hml'
NODE = HOME / '.local' / 'node-v24.20.0' / 'bin' / 'node'
PORTS = {'central':18100, 'diagnostic':18110, 'keycloak':18120}
MIN_FREE_DISK_GIB = 6
MIN_FREE_MEMORY_MIB = 2500

class SafetyError(Exception):
    pass

def fail(message: str):
    raise SafetyError(message)

def ensure_owner(path: Path, *, file=False):
    if path.is_symlink():fail('Link simbolico recusado em caminho da homologacao.')
    # Inspect every ancestor beneath the staging root, not arbitrary system dirs.
    if path == ROOT or ROOT in path.parents:
        p = path
        while p != ROOT.parent:
            if p.is_symlink():fail('Link simbolico recusado em caminho da homologacao.')
            if p.exists() and p.stat().st_uid != os.geteuid():fail('Arquivo/pasta da HML com outro proprietario.')
            p = p.parent
    if file and (not path.is_file() or path.stat().st_nlink != 1):
        fail('Arquivo esperado ausente ou hard link recusado.')

def require_user():
    if os.geteuid() == 0:fail('Execute como deploy, SEM sudo.')
    if HOME != Path('/home/deploy'):
        fail('Usuario/home inesperados. Este pacote foi preparado para /home/deploy.')

def read_env(path: Path):
    ensure_owner(path,file=True)
    if path.stat().st_size > 100_000:fail('Arquivo .env inesperadamente grande.')
    values={}
    for line in path.read_text('utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        if '=' not in line:fail('Linha invalida em .env.')
        key,value=line.split('=',1)
        if not re.fullmatch(r'[A-Z_][A-Z_0-9]*',key) or key in values:
            fail('Chave duplicada/invalida no ambiente.')
        values[key]=value
    return values

def previous_migration():
    # Re-use all checksums and safety validations from the applied Delivery 06.
    if not PREVIOUS.is_file():fail('Pacote Entrega 06 original nao encontrado na home. Nao reconfigure manualmente.')
    spec=importlib.util.spec_from_file_location('entrega06_checked',PREVIOUS)
    if not spec or not spec.loader:fail('Nao foi possivel carregar a Entrega 06.')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    try:
        module.verify_package()
        module.load_state(ROOT)
        module.check_ledger(ROOT)
    except (module.SafetyError,OSError,ValueError,KeyError) as exc:
        # Do not echo a path/content from potentially sensitive files.
        fail('Validacao de integridade da Entrega 06 falhou. Revise com entrega06.py verificar.')
    return module

def check_config():
    require_user()
    ensure_owner(ROOT)
    if not ROOT.is_dir():fail('Homologacao nao existe; nao crie outra automaticamente.')
    previous_migration()
    central=read_env(ROOT/'central/.env')
    diagnostic=read_env(ROOT/'diagnostic/.env')
    secret=read_env(KEYCLOAK/'.env')
    must_c={'NODE_ENV':'production','APP_ENV':'homologacao','HOST':'127.0.0.1','PORT':'18100',
            'PUBLIC_ORIGIN':ORIGIN,'BASE_PATH':'/app','OIDC_ISSUER':ISSUER,
            'OIDC_CLIENT_ID':CLIENT_ID,'OIDC_ALLOW_HTTP':'false',
            'DIAGNOSTIC_UPSTREAM':'http://127.0.0.1:18110'}
    must_d={'NODE_ENV':'production','APP_ENV':'homologacao','HOST':'127.0.0.1','PORT':'18110',
            'PLATFORM_ENABLED':'true','PLATFORM_PUBLIC_ORIGIN':ORIGIN,
            'PLATFORM_ALLOW_LEGACY':'false','FRONTEND_URL':ORIGIN}
    if any(central.get(k)!=v for k,v in must_c.items()):fail('Central tem config de dominio/isolamento divergente.')
    if any(diagnostic.get(k)!=v for k,v in must_d.items()):fail('Diagnostic tem config de dominio/isolamento divergente.')
    if len(central.get('OIDC_CLIENT_SECRET',''))<32:fail('Segredo OIDC ausente/curto.')
    if not secret.get('POSTGRES_PASSWORD') or not secret.get('KC_BOOTSTRAP_ADMIN_PASSWORD'):
        fail('Credenciais privadas do Keycloak ausentes.')
    realm_file=KEYCLOAK/'realm-import'/'casadoads-hml-realm.json'
    ensure_owner(realm_file,file=True)
    realm=json.loads(realm_file.read_text('utf-8'))
    clients=[c for c in realm.get('clients',[]) if c.get('clientId')==CLIENT_ID]
    if realm.get('realm')!=REALM or len(clients)!=1:fail('Realm/client inesperados.')
    client=clients[0]
    if client.get('secret')!=central['OIDC_CLIENT_SECRET']:
        fail('Segredo OIDC entre Central e realm nao corresponde.')
    if client.get('redirectUris')!=[ORIGIN+'/app/auth/callback'] or client.get('webOrigins')!=[ORIGIN]:
        fail('URI de retorno de login nao corresponde.')
    ensure_owner(COMPOSE,file=True)
    compose=COMPOSE.read_text('utf-8')
    if ('KC_HOSTNAME: https://'+LOGIN not in compose
        or '127.0.0.1:18120:8080' not in compose
        or 'casadoads_hml_oidc_postgres_data' not in compose
        or 'quay.io/keycloak/keycloak:26.8.1' not in compose):
        fail('Compose diferente da configuracao esperada da homologacao.')
    if not NODE.is_file():fail('Node exclusivo da homologacao nao encontrado.')
    if not (ROOT/'central/node_modules/openid-client/package.json').is_file():
        fail('Dependencias da Central faltando; Entrega 06 instalar-central.')
    if not (ROOT/'diagnostic/node_modules/vite/package.json').is_file() or not (ROOT/'diagnostic/dist/index.html').is_file():
        fail('Dependencias/build Diagnostic faltando; Entrega 06 instalar-diagnostic.')
    for path in (ROOT/'central/.keys/gateway-private.pem', ROOT/'diagnostic/.platform/gateway-public.pem'):
        ensure_owner(path,file=True)
    return {'central':central,'diagnostic':diagnostic,'keycloak':secret}

def memory_mib():
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            if line.startswith('MemAvailable:'):return int(line.split()[1])//1024
    except (OSError,ValueError):pass
    return None

def resources():
    disk=shutil.disk_usage(ROOT).free//(1024**2)
    mem=memory_mib()
    return {'memoria_disponivel_mib':mem,'disco_livre_mib':disk}

def assert_resources():
    stats=resources()
    if stats['memoria_disponivel_mib'] is None or stats['memoria_disponivel_mib']<MIN_FREE_MEMORY_MIB:
        fail('RAM insuficiente para iniciar novos processos na maquina compartilhada.')
    if stats['disco_livre_mib']<MIN_FREE_DISK_GIB*1024:
        fail('Disco insuficiente para imagens/banco da HML.')
    return stats

def tcp_used(port):
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try:s.bind(('127.0.0.1',port));return False
        except OSError:return True

def dns_a(host):
    try:return sorted({item[4][0] for item in socket.getaddrinfo(host,443,family=socket.AF_INET,type=socket.SOCK_STREAM)})
    except (socket.gaierror,OSError):return []

def tls_cert_ok(host):
    try:
        ctx=ssl.create_default_context()
        with socket.create_connection((host,443),timeout=7) as s:
            with ctx.wrap_socket(s,server_hostname=host) as tls:
                cert=tls.getpeercert()
                return bool(cert.get('notAfter'))
    except (OSError,ssl.SSLError,TimeoutError):return False

def check_domains():
    results={}
    for name in (HOST,LOGIN):
        records=dns_a(name)
        results[name]={'A':records,'ipv4_esperado':EXPECTED_IP in records,'tls_valido':tls_cert_ok(name) if EXPECTED_IP in records else False}
    return results

def url_get(url,*,limit=100_000):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),NoRedirect)
    req=urllib.request.Request(url,headers={'User-Agent':'CasaDoAds-HML-Entrega07/1.0','Cache-Control':'no-store'})
    try:response=opener.open(req,timeout=10)
    except urllib.error.HTTPError as exc:response=exc
    with response:
        return response.status,response.read(limit),response.headers.get('Location','')

def local_get(port,path):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,headers={'User-Agent':'CasaDoAds-HML-Entrega07/1.0'})
    try:r=opener.open(req,timeout=6)
    except urllib.error.HTTPError as exc:r=exc
    with r:return r.status,r.read(100_000)

def issuer_ready():
    try:
        status,body,_=url_get(ISSUER+'/.well-known/openid-configuration')
        j=json.loads(body)
        return status==200 and j.get('issuer')==ISSUER
    except (ValueError,OSError,urllib.error.URLError,TimeoutError):return False

def local_realm_ready():
    try:
        status,body=local_get(18120,'/realms/casadoads-hml/.well-known/openid-configuration')
        return status==200 and json.loads(body).get('issuer')==ISSUER
    except (ValueError,OSError,urllib.error.URLError,TimeoutError):return False

def run_quiet(args,cwd,timeout=30):
    try:
        cp=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=timeout,check=False)
    except (OSError,subprocess.TimeoutExpired):
        fail('Comando local indisponivel/expirado; nenhum processo externo foi encerrado.')
    return cp

def docker_state():
    daemon=run_quiet(['docker','info','--format','{{.ServerVersion}}'],KEYCLOAK,timeout=12)
    if daemon.returncode:return {'disponivel':False,'containers':None,'volume':None,'rede':None}
    ps=run_quiet(['docker','ps','-a','--format','{{.ID}}','--filter','label=com.docker.compose.project='+PROJECT],KEYCLOAK)
    volume=run_quiet(['docker','volume','inspect',VOLUME],KEYCLOAK)
    network=run_quiet(['docker','network','inspect',NETWORK],KEYCLOAK)
    if ps.returncode:fail('Nao foi possivel auditar containers existentes.')
    return {'disponivel':True,'containers':bool(ps.stdout.strip()),'volume':volume.returncode==0,'rede':network.returncode==0}

def process_state(pid):
    try:
        contents=Path('/proc')/str(pid)/'stat'
        s=contents.read_text()
        # /proc/pid/stat: split following the final ')' to avoid spaces in comm.
        return s.rsplit(')',1)[1].strip().split()[19]
    except (FileNotFoundError,PermissionError,ValueError,IndexError):return None

def pid_file(app):return PRIVATE/(app+'.pid.json')

def read_pid(app):
    p=pid_file(app)
    if not p.exists():return None
    ensure_owner(p,file=True)
    try:obj=json.loads(p.read_text('utf-8'))
    except (ValueError,OSError):fail('Registro de processo invalido; nao altere manualmente.')
    if set(obj)!={'app','pid','starttime','cwd'} or obj['app']!=app or obj['cwd']!=str(ROOT/app):
        fail('Registro PID inesperado; nao encerrar processos.')
    if not isinstance(obj['pid'],int) or obj['pid']<=1 or not str(obj['starttime']).isdigit():
        fail('Registro PID inesperado.')
    return obj

def status_app(app):
    o=read_pid(app)
    if o is None:return {'registrado':False,'ativo':False}
    active=(process_state(o['pid'])==o['starttime'])
    return {'registrado':True,'ativo':active}

def prepare_private():
    ensure_owner(ROOT/'privado')
    ensure_owner(PRIVATE)
    PRIVATE.mkdir(mode=0o700,exist_ok=True)
    if PRIVATE.stat().st_uid!=os.geteuid():fail('Pasta privada da entrega 07 nao pertence ao deploy.')
    PRIVATE.chmod(0o700)

def lock():
    prepare_private()
    p=PRIVATE/'operacao.lock'
    ensure_owner(p)
    fp=p.open('a+')
    os.chmod(p,0o600)
    try:fcntl.flock(fp,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:fp.close();fail('Outra operacao da entrega 07 esta em andamento.')
    return fp

def verify():
    check_config()
    return {'entrega':7,'modo':'somente_leitura','dominio_principal_preservado':'workspacecasadoads.com.br',
            'base_hml':str(ROOT),'config_validada':True,'recursos':resources(),
            'dominios':check_domains(),
            'portas_em_uso':{str(p):tcp_used(p) for p in PORTS.values()},
            'processos_entrega07':{a:status_app(a) for a in ('central','diagnostic')},
            'docker':docker_state(),
            'issuer_publico_pronto':issuer_ready(),
            'keycloak_local_pronto':local_realm_ready(),
            'producao_modificada_pelo_verificador':False,'academy_alterado':False}

def keycloak_start():
    check_config();assert_resources()
    domains=check_domains()
    if not all(d['ipv4_esperado'] and d['tls_valido'] for d in domains.values()):
        fail('DNS A ou TLS dos dois hosts nao verificados; nao iniciar Keycloak.')
    state=docker_state()
    if not state['disponivel']:
        fail('Docker nao disponivel ao usuario deploy. Nao use sudo automaticamente.')
    if state['containers'] or state['volume'] or state['rede'] or tcp_used(18120):
        fail('Containers/volume/rede/porta Keycloak ja existentes. Nao recriar ou sobrepor; envie o relatorio.')
    if run_quiet(['docker','compose','-p',PROJECT,'config','--quiet'],KEYCLOAK,timeout=20).returncode:
        fail('Docker Compose config invalido; revisar no VPS sem divulgar variaveis.')
    result=run_quiet(['docker','compose','-p',PROJECT,'up','-d','--no-build','postgres','keycloak'],KEYCLOAK,timeout=1200)
    if result.returncode:
        fail('Docker Compose nao concluiu. Pode ter criado containers/volume; NAO repita sem verificar docker compose ps.')
    return {'acao':'keycloak_iniciado_ou_criado','projeto':PROJECT,'banco_persistente':VOLUME,
            'issuer_local_respondendo_agora':local_realm_ready(),
            'issuer_publico_respondendo_agora':issuer_ready(),
            'nota':'Se ainda nao estiver pronto, consulte docker compose ps e logs na pasta privada. Nao apague volumes.',
            'nginx_ou_producao_alterados':False}

def launch(app):
    if app not in ('central','diagnostic'):fail('Aplicacao invalida.')
    check_config();assert_resources()
    if not issuer_ready():fail('Keycloak publico ainda nao responde com issuer correto. Inicie/valide Keycloak primeiro.')
    if tcp_used(PORTS[app]) or read_pid(app) is not None:
        fail('Processo/porta do modulo ja existe; nao iniciar duplicata.')
    log_file=PRIVATE/(app+'-processo.log')
    pid_path=pid_file(app)
    if log_file.exists() or pid_path.exists():
        fail('Log/PID ja existe de tentativa anterior; revisar antes de reiniciar.')
    # Record the service launch only inside this isolated staging directory.
    with log_file.open('xb') as logfile:
        os.chmod(log_file,0o600)
        env={'PATH':str(NODE.parent)+':/usr/local/bin:/usr/bin:/bin',
             'HOME':str(ROOT/'privado'), 'LANG':'C.UTF-8',
             'TMPDIR':str(ROOT/'tmp'), 'XDG_CACHE_HOME':str(ROOT/'cache')}
        script='server/index.mjs' if app=='central' else 'server/index.js'
        cmd=[str(NODE),'--max-old-space-size=256','--env-file=.env',script]
        proc=subprocess.Popen(cmd,cwd=ROOT/app,env=env,stdin=subprocess.DEVNULL,
                              stdout=logfile,stderr=subprocess.STDOUT,close_fds=True,start_new_session=True)
    # Keep start time so a later PID reuse cannot cause a stop of another app.
    starttime=None
    for _ in range(25):
        starttime=process_state(proc.pid)
        if starttime:break
        time.sleep(0.04)
    if not starttime:
        fail('Processo nao retornou starttime. Revise o log privado. Nao use kill em PID copiado.')
    with pid_path.open('x') as fp:
        os.chmod(pid_path,0o600)
        json.dump({'app':app,'pid':proc.pid,'starttime':starttime,'cwd':str(ROOT/app)},fp)
        fp.write('\n')
    healthy=False
    testpath='/healthz' if app=='central' else '/api/health'
    for _ in range(35):
        if proc.poll() is not None:break
        try:
            code,body=local_get(PORTS[app],testpath)
            if code==200 and json.loads(body).get('ok') is True:
                healthy=True;break
        except (OSError,ValueError,urllib.error.URLError,TimeoutError):pass
        time.sleep(0.6)
    return {'acao':'processo_hml_iniciado','app':app,'saudavel_agora':healthy,
            'log_privado':str(log_file),'nginx_modificado':False,'pm2_tocado':False,
            'observacao':'Processo de piloto, nao configurado para reiniciar apos reboot.'}

def stop(app):
    o=read_pid(app)
    if not o:fail('Sem registro de processo nesta entrega; nenhum processo encerrado.')
    pid=o['pid']
    if process_state(pid)!=o['starttime']:
        fail('PID ausente/reutilizado. Nenhum sinal enviado; revise o registro manualmente.')
    cwd_link=Path('/proc')/str(pid)/'cwd'
    try:current_cwd=os.readlink(cwd_link)
    except OSError:fail('Nao foi possivel verificar diretorio do processo; nenhum sinal enviado.')
    if current_cwd!=o['cwd']:fail('Diretorio do processo mudou. Nenhum sinal enviado.')
    os.kill(pid,signal.SIGTERM)
    # No SIGKILL, no PM2/systemd/docker actions.
    return {'acao':'sigterm_enviado','app':app,'alvo_verificado':True,
            'observacao':'Aguarde encerramento e confira estado. Registro nao apagado automaticamente.'}

def archive_stopped(app):
    o=read_pid(app)
    if not o:fail('Nao existe registro de inicializacao dessa aplicacao.')
    if process_state(o['pid'])==o['starttime']:
        fail('O processo original ainda esta ativo; nao arquivar registro.')
    if tcp_used(PORTS[app]):
        fail('Porta ainda ocupada; nao preparar nova inicializacao.')
    stamp=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
    for item in (pid_file(app),PRIVATE/(app+'-processo.log')):
        if item.exists():
            dest=item.with_name(item.name+'.anterior-'+stamp)
            if dest.exists():fail('Destino de arquivo ja existe; nao sobrescrever.')
            item.rename(dest)
    return {'acao':'registros_do_processo_parado_arquivados','app':app,
            'aplicacoes_reiniciadas':False,'nenhum_processo_encerrado':True}

def validate():
    check_config()
    checks={'tls_dois_hosts':all(x['tls_valido'] for x in check_domains().values()),
            'issuer_respondendo':issuer_ready(),'keycloak_local':local_realm_ready()}
    try:
        c,body,_=url_get(ORIGIN+'/app/api/platform/me')
        j=json.loads(body)
        checks['central_anonima']=c==200 and j.get('authenticated') is False and j.get('oidcConfigured') is True
    except (ValueError,OSError,urllib.error.URLError,TimeoutError):checks['central_anonima']=False
    try:
        d,body,_=url_get(ORIGIN+'/app/diagnostico/api/vendedor/me')
        checks['diagnostic_bloqueado_sem_login']=d==401
    except (OSError,urllib.error.URLError,TimeoutError):checks['diagnostic_bloqueado_sem_login']=False
    try:
        d,body=local_get(18110,'/api/health')
        checks['diagnostic_local']=d==200 and json.loads(body).get('ok') is True
    except (ValueError,OSError,urllib.error.URLError,TimeoutError):checks['diagnostic_local']=False
    try:
        status,_,location=url_get(ORIGIN+'/app/auth/login',limit=0)
        checks['login_redireciona_para_keycloak']=status in (302,303) and location.startswith(ISSUER+'/protocol/openid-connect/auth?')
    except (ValueError,OSError,urllib.error.URLError,TimeoutError):checks['login_redireciona_para_keycloak']=False
    return {'etapa':'07','validacao':checks,'tudo_aprovado':all(checks.values()),
            'observacao':'Nao testa senha, login completo, concessao de permissoes ou IA. O GET de login cria sessao anonima apenas na HML.'}

def token_admin(env):
    # Admin password flows exclusively over loopback and never reaches stdout or argv.
    password=env['KC_BOOTSTRAP_ADMIN_PASSWORD']
    data=urllib.parse.urlencode({'grant_type':'password','client_id':'admin-cli','username':'admin','password':password}).encode('utf-8')
    req=urllib.request.Request('http://127.0.0.1:18120/realms/master/protocol/openid-connect/token',data=data,method='POST',
        headers={'Content-Type':'application/x-www-form-urlencoded'})
    with urllib.request.urlopen(req,timeout=12) as r:
        parsed=json.loads(r.read(100_000))
    token=parsed.get('access_token')
    if not isinstance(token,str) or not token:fail('Token administrativo ausente.')
    return token

def create_test_user(username):
    check_config()
    if not re.fullmatch(r'[a-z][a-z0-9._-]{2,39}',username) or username in {'admin','master','root'}:
        fail('Usuario de teste invalido. Use 3-40 caracteres minusculos (a-z, 0-9, . _ -).')
    if not local_realm_ready():fail('Keycloak de homologacao nao esta pronto.')
    if not sys.stdin.isatty():fail('Criacao de conta exige um terminal interativo para ocultar a senha.')
    password=getpass.getpass('Senha TEMPORARIA do teste (14+ caracteres): ')
    confirm=getpass.getpass('Repita a senha: ')
    if len(password)<14 or password!=confirm:
        fail('Senha curta ou confirmacao diferente. Nenhum usuario criado.')
    creds=read_env(KEYCLOAK/'.env')
    try:
        token=token_admin(creds)
        endpoint='http://127.0.0.1:18120/admin/realms/casadoads-hml/users'
        form={'username':username,'enabled':True,'credentials':[{'type':'password','value':password,'temporary':True}]}
        data=json.dumps(form,separators=(',',':')).encode('utf-8')
        request=urllib.request.Request(endpoint,data=data,method='POST',headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=20) as response:
            if response.status!=201:fail('Keycloak nao retornou HTTP 201; confira estado no painel local.')
    except urllib.error.HTTPError as exc:
        if exc.code==409:fail('Usuario ja existe no realm HML; nenhuma senha alterada.')
        fail('Falha na operacao administrativa local com Keycloak (HTTP '+str(exc.code)+').')
    except (urllib.error.URLError,TimeoutError,ValueError):
        fail('Falha local de autenticacao/administracao do Keycloak; nao tente em producao.')
    finally:
        password='';confirm=''
    return {'acao':'usuario_de_teste_criado','realm':REALM,'usuario':username,
            'senha_exibida':False,'senha_deve_mudar_no_primeiro_login':True,
            'permissoes_concedidas':False}

def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('acao',choices=['verificar','iniciar-keycloak','iniciar-central','iniciar-diagnostic','validar','criar-usuario','parar-central','parar-diagnostic','arquivar-central','arquivar-diagnostic'])
    parser.add_argument('--confirmar',action='store_true')
    parser.add_argument('--usuario',help='Somente para criar-usuario, exemplo teste.central')
    args=parser.parse_args()
    try:
        require_user()
        actions={'verificar','validar'}
        if args.acao not in actions and not args.confirmar:
            fail('Acao de mudanca exige --confirmar (veja o README).')
        if args.acao=='verificar':result=verify()
        elif args.acao=='validar':result=validate()
        elif args.acao=='iniciar-keycloak':
            with lock():result=keycloak_start()
        elif args.acao=='iniciar-central':
            with lock():result=launch('central')
        elif args.acao=='iniciar-diagnostic':
            with lock():result=launch('diagnostic')
        elif args.acao=='criar-usuario':
            if not args.usuario:fail('Indique --usuario teste.central (nao use contas reais).')
            with lock():result=create_test_user(args.usuario)
        elif args.acao=='parar-central':
            with lock():result=stop('central')
        elif args.acao=='parar-diagnostic':
            with lock():result=stop('diagnostic')
        elif args.acao=='arquivar-central':
            with lock():result=archive_stopped('central')
        elif args.acao=='arquivar-diagnostic':
            with lock():result=archive_stopped('diagnostic')
        else:fail('Acao inesperada.')
        print(json.dumps(result,indent=2,ensure_ascii=False))
        return 0
    except (SafetyError,OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
        # Avoid rendering potentially sensitive error messages from dependencies.
        print('ERRO: '+str(exc),file=sys.stderr)
        return 1

if __name__=='__main__':
    sys.exit(main())
