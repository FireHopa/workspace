# Notas operacionais e limites da Entrega 07

## Integridade e escopo

`entrega07.py` depende da Entrega 06 **aplicada** e da pasta original `~/Entrega_06_Troca_Dominio_Workspace`, e reutiliza a verificacao de checksums para impedir inicializacao com arquivos divergentes. Nao oferece `--force`.

Todos os arquivos gravados pelo auxiliar Python ficam em:

`/home/deploy/plataforma-hml-entrega02/privado/entrega07/`

A unica excecao sao os containers, rede e volume de homologacao explicitamente criados pelo `docker compose` na pasta privada da Entrega 03. A estrutura do Keycloak tem banco PostgreSQL e volume exclusivo `casadoads_hml_oidc_postgres_data`, sem porta do banco publicada no host. A porta Keycloak `18120` e publicada apenas em loopback. O Nginx ja foi instalado na etapa anterior; nao ha reload do Nginx nesta entrega.

## Quando bloquear

- `docker.containers`, `docker.volume` ou `docker.rede` ja existentes antes da primeira inicializacao: nao recriar nem apagar; documentar e analisar.
- Falha de TLS ou DNS dos dois nomes, issuer errado, segredos/client divergentes: nao iniciar.
- Node nao encontrado, dependencias/build ausentes, portas ocupadas, PID existente: nao iniciar duplicatas.
- Memoria disponivel inferior a 2500 MiB ou disco livre abaixo de 6 GiB: nao iniciar novos processos.
- Alteracoes posteriores nos arquivos monitorados pela Entrega 06: interromper; nao editar os checksums para contornar.

## Keycloak e administracao

A API administrativa e usada apenas sobre `http://127.0.0.1:18120` e o programa recebe a senha administrativa do `.env` existente, em memoria; nunca a passa como argumento de linha de comando. A operacao de criar usuario pede senha temporaria por `getpass` e nao a imprime. A interface `/admin/` permanece indisponivel externamente.

Se ja houver outro Keycloak no Docker, nao altere o Compose de outro projeto. Nao utilize `docker compose down -v`; esse comando apaga o banco de homologacao. Para **apenas parar** os containers de homologacao, apos confirmar que esse e o projeto esperado e fazer backup de dados relevantes:

```bash
cd ~/plataforma-hml-entrega02/privado/entrega03/keycloak
docker compose -p casadoads_hml_oidc stop
```

Esse comando nao remove containers ou volumes. Nao foi incorporado ao auxiliar para evitar parada acidental do provedor de login depois de haver usuarios de teste.

## Persistencia dos processos Node

Nesta etapa os processos de Central e Diagnostic sao iniciados em sessoes independentes, sem PM2 e sem systemd. O script guarda o PID com o tempo de inicializacao fornecido pelo kernel; ao pedir parada, confere o PID, starttime e diretorio antes de enviar SIGTERM. Mesmo assim, um processo pode sair por conta propria e os registros ficam para diagnostico. Isso evita reiniciar ou matar um servico nao identificado.

Para uma instalacao permanente, planeje **unidades systemd proprias da HML** ou outro supervisor isolado, apos o piloto ter login e permissao de vendedor validados. Nao insira estas aplicacoes na mesma configuracao PM2 da producao sem uma revisao independente.

## Seguranca de rede

TLS ja esta no Nginx e os novos servicos usam HTTP somente no loopback. No Compose, `KC_HTTP_ENABLED=true`, `KC_PROXY_HEADERS=xforwarded`, `KC_HOSTNAME=https://login-hml.workspacecasadoads.com.br`, conforme o modelo da etapa anterior. O proxy Nginx sobrescreve `X-Forwarded-*` para impedir valores falsificados. O endpoint administrativo `/admin/` continua bloqueado externamente.

Docs oficiais: https://www.keycloak.org/server/reverseproxy e https://www.keycloak.org/server/hostname

## O que conta como concluido

`validar` precisa retornar `tudo_aprovado: true`, seguido por login pelo navegador, primeiro usuario existente no banco da Central, concessao de admin com `subject` exato, vinculacao de um vendedor existente e teste de historico na homologacao. Geracao de IA permanece fora enquanto API keys da HML estiverem vazias. Retorno HTTP 200 da pagina inicial, isoladamente, nao valida essas funcoes.
