import signal
import urllib.error
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import types
import unittest
from unittest.mock import patch, MagicMock
import importlib.util

SRC=Path(__file__).resolve().parents[1]/'entrega07.py'
spec=importlib.util.spec_from_file_location('entrega07_tests',SRC)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ORIGINAL_REQUIRE_USER=m.require_user

class DummyResponse:
    def __init__(self, status=201, body=b'{}'):
        self.status=status;self.body=body
    def __enter__(self):return self
    def __exit__(self,*_):pass
    def read(self,n=100000):return self.body[:n]

class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.home=Path(self.temp.name)/'deploy'
        self.home.mkdir()
        self.root=self.home/'plataforma-hml-entrega02'
        self.root.mkdir()
        self.keycloak=self.root/'privado'/'entrega03'/'keycloak'
        self.keycloak.mkdir(parents=True)
        for app in ('central','diagnostic'):(self.root/app).mkdir()
        self.private=self.root/'privado'/'entrega07'
        self.node=self.home/'bin'/'node'
        self.node.parent.mkdir();self.node.write_text('fake')
        self._patch=[patch.object(m,'HOME',self.home),patch.object(m,'ROOT',self.root),
                     patch.object(m,'KEYCLOAK',self.keycloak),patch.object(m,'COMPOSE',self.keycloak/'docker-compose.yml'),
                     patch.object(m,'PRIVATE',self.private),patch.object(m,'NODE',self.node),
                     patch.object(m,'require_user',return_value=None),
                     patch.object(m,'previous_migration',return_value=None)]
        for item in self._patch:item.start()
        secret='a'*48
        cen={'NODE_ENV':'production','APP_ENV':'homologacao','HOST':'127.0.0.1','PORT':'18100',
            'PUBLIC_ORIGIN':m.ORIGIN,'BASE_PATH':'/app','OIDC_ISSUER':m.ISSUER,
            'OIDC_CLIENT_ID':m.CLIENT_ID,'OIDC_CLIENT_SECRET':secret,'OIDC_ALLOW_HTTP':'false',
            'DIAGNOSTIC_UPSTREAM':'http://127.0.0.1:18110'}
        dia={'NODE_ENV':'production','APP_ENV':'homologacao','HOST':'127.0.0.1','PORT':'18110',
             'PLATFORM_ENABLED':'true','PLATFORM_PUBLIC_ORIGIN':m.ORIGIN,
             'PLATFORM_ALLOW_LEGACY':'false','FRONTEND_URL':m.ORIGIN}
        self.writeenv(self.root/'central/.env',cen)
        self.writeenv(self.root/'diagnostic/.env',dia)
        self.writeenv(self.keycloak/'.env',{'POSTGRES_PASSWORD':'z'*50,'KC_BOOTSTRAP_ADMIN_PASSWORD':'y'*50})
        (self.keycloak/'realm-import').mkdir()
        (self.keycloak/'realm-import'/'casadoads-hml-realm.json').write_text(json.dumps({
            'realm':m.REALM,'clients':[{'clientId':m.CLIENT_ID,'secret':secret,
                                       'redirectUris':[m.ORIGIN+'/app/auth/callback'],
                                       'webOrigins':[m.ORIGIN]}]}))
        (self.keycloak/'docker-compose.yml').write_text('KC_HOSTNAME: https://'+m.LOGIN+'\n"127.0.0.1:18120:8080"\nquay.io/keycloak/keycloak:26.8.1\ncasadoads_hml_oidc_postgres_data\n')
        (self.root/'central/node_modules/openid-client').mkdir(parents=True)
        (self.root/'central/node_modules/openid-client/package.json').write_text('{}')
        (self.root/'diagnostic/node_modules/vite').mkdir(parents=True)
        (self.root/'diagnostic/node_modules/vite/package.json').write_text('{}')
        (self.root/'diagnostic/dist').mkdir()
        (self.root/'diagnostic/dist/index.html').write_text('ok')
        (self.root/'central/.keys').mkdir()
        (self.root/'diagnostic/.platform').mkdir()
        (self.root/'central/.keys/gateway-private.pem').write_text('private')
        (self.root/'diagnostic/.platform/gateway-public.pem').write_text('public')
    def tearDown(self):
        for item in reversed(self._patch):item.stop()
        self.temp.cleanup()
    def writeenv(self,p,values):
        p.write_text(''.join(f'{k}={v}\n' for k,v in values.items()))

    def test_config_ok(self):
        conf=m.check_config()
        self.assertEqual(conf['central']['OIDC_ISSUER'],m.ISSUER)
    def test_central_origin_mismatch(self):
        p=self.root/'central/.env';p.write_text(p.read_text().replace(m.ORIGIN,'https://wrong.test'))
        with self.assertRaises(m.SafetyError):m.check_config()
    def test_conf_secret_match(self):
        p=self.root/'central/.env';p.write_text(p.read_text().replace('a'*48,'b'*48))
        with self.assertRaisesRegex(m.SafetyError,'Segredo OIDC'):m.check_config()
    def test_realm_callback_match(self):
        p=self.keycloak/'realm-import/casadoads-hml-realm.json'
        p.write_text(p.read_text().replace('auth/callback','auth/callback2'))
        with self.assertRaises(m.SafetyError):m.check_config()
    def test_no_legacy_allowed(self):
        p=self.root/'diagnostic/.env';p.write_text(p.read_text().replace('PLATFORM_ALLOW_LEGACY=false','PLATFORM_ALLOW_LEGACY=true'))
        with self.assertRaises(m.SafetyError):m.check_config()
    def test_readenv_duplicate(self):
        p=self.root/'central/.env'
        p.write_text(p.read_text()+'PORT=3\n')
        with self.assertRaises(m.SafetyError):m.read_env(p)
    def test_no_symlink_sensitive_path(self):
        p=self.root/'central/.env';p.rename(self.root/'central/keep.env')
        p.symlink_to(self.root/'central/keep.env')
        with self.assertRaises(m.SafetyError):m.read_env(p)
    def test_no_root(self):
        with patch.object(m.os,'geteuid',return_value=0):
            with self.assertRaises(m.SafetyError):ORIGINAL_REQUIRE_USER()
    def test_resource_guard(self):
        with patch.object(m,'resources',return_value={'memoria_disponivel_mib':100,'disco_livre_mib':100}):
            with self.assertRaises(m.SafetyError):m.assert_resources()
    def test_resource_sufficient(self):
        with patch.object(m,'resources',return_value={'memoria_disponivel_mib':9000,'disco_livre_mib':12000}):
            self.assertEqual(m.assert_resources()['disco_livre_mib'],12000)
    def test_dns_missing_skips_tls(self):
        with patch.object(m,'dns_a',return_value=[]),patch.object(m,'tls_cert_ok') as tls:
            values=m.check_domains()
            self.assertFalse(values[m.HOST]['tls_valido']);tls.assert_not_called()
    def test_dns_expected(self):
        with patch.object(m,'dns_a',return_value=[m.EXPECTED_IP]),patch.object(m,'tls_cert_ok',return_value=True):
            self.assertTrue(m.check_domains()[m.HOST]['tls_valido'])
    def test_docker_state_empty(self):
        outputs=[types.SimpleNamespace(returncode=0,stdout='27.1'),
                 types.SimpleNamespace(returncode=0,stdout=''),
                 types.SimpleNamespace(returncode=1,stdout=''),
                 types.SimpleNamespace(returncode=1,stdout='')]
        with patch.object(m,'run_quiet',side_effect=outputs):
            self.assertEqual(m.docker_state(),{'disponivel':True,'containers':False,'volume':False,'rede':False})
    def test_docker_unavailable(self):
        with patch.object(m,'run_quiet',return_value=types.SimpleNamespace(returncode=1,stdout='')):
            self.assertFalse(m.docker_state()['disponivel'])
    def test_keycloak_refuse_prior_volume(self):
        with patch.object(m,'assert_resources'),patch.object(m,'check_domains',return_value={m.HOST:{'ipv4_esperado':True,'tls_valido':True},m.LOGIN:{'ipv4_esperado':True,'tls_valido':True}}),patch.object(m,'docker_state',return_value={'disponivel':True,'containers':False,'volume':True,'rede':False}),patch.object(m,'run_quiet') as run:
            with self.assertRaises(m.SafetyError):m.keycloak_start()
            run.assert_not_called()
    def test_keycloak_refuse_missing_tls(self):
        with patch.object(m,'assert_resources'),patch.object(m,'check_domains',return_value={m.HOST:{'ipv4_esperado':False,'tls_valido':False},m.LOGIN:{'ipv4_esperado':True,'tls_valido':True}}),patch.object(m,'run_quiet') as run:
            with self.assertRaises(m.SafetyError):m.keycloak_start()
            run.assert_not_called()
    def test_keycloak_success(self):
        with patch.object(m,'assert_resources'),patch.object(m,'check_domains',return_value={m.HOST:{'ipv4_esperado':True,'tls_valido':True},m.LOGIN:{'ipv4_esperado':True,'tls_valido':True}}),patch.object(m,'docker_state',return_value={'disponivel':True,'containers':False,'volume':False,'rede':False}),patch.object(m,'tcp_used',return_value=False),patch.object(m,'run_quiet',return_value=types.SimpleNamespace(returncode=0,stdout='')),patch.object(m,'local_realm_ready',return_value=True),patch.object(m,'issuer_ready',return_value=True):
            self.assertTrue(m.keycloak_start()['issuer_publico_respondendo_agora'])
    def test_keycloak_refuse_prior_network(self):
        with patch.object(m,'assert_resources'),patch.object(m,'check_domains',return_value={m.HOST:{'ipv4_esperado':True,'tls_valido':True},m.LOGIN:{'ipv4_esperado':True,'tls_valido':True}}),patch.object(m,'docker_state',return_value={'disponivel':True,'containers':False,'volume':False,'rede':True}),patch.object(m,'run_quiet') as run:
            with self.assertRaises(m.SafetyError):m.keycloak_start()
            run.assert_not_called()
    def test_keycloak_failed_up_does_not_claim_success(self):
        with patch.object(m,'assert_resources'),patch.object(m,'check_domains',return_value={m.HOST:{'ipv4_esperado':True,'tls_valido':True},m.LOGIN:{'ipv4_esperado':True,'tls_valido':True}}),patch.object(m,'docker_state',return_value={'disponivel':True,'containers':False,'volume':False,'rede':False}),patch.object(m,'tcp_used',return_value=False),patch.object(m,'run_quiet',side_effect=[types.SimpleNamespace(returncode=0,stdout=''),types.SimpleNamespace(returncode=1,stdout='')]):
            with self.assertRaisesRegex(m.SafetyError,'Pode ter criado'):m.keycloak_start()
    def test_launch_refuse_issuer_down(self):
        with patch.object(m,'assert_resources'),patch.object(m,'issuer_ready',return_value=False),patch.object(m.subprocess,'Popen') as popen:
            with self.assertRaises(m.SafetyError):m.launch('central')
            popen.assert_not_called()
    def test_launch_refuse_busy_port(self):
        with patch.object(m,'assert_resources'),patch.object(m,'issuer_ready',return_value=True),patch.object(m,'tcp_used',return_value=True),patch.object(m.subprocess,'Popen') as popen:
            with self.assertRaises(m.SafetyError):m.launch('diagnostic')
            popen.assert_not_called()
    def test_status_no_pid(self):
        self.assertEqual(m.status_app('central'),{'registrado':False,'ativo':False})
    def test_stale_pid_no_kill(self):
        m.prepare_private()
        (m.pid_file('central')).write_text(json.dumps({'app':'central','pid':123,'starttime':'999','cwd':str(self.root/'central')}))
        with patch.object(m,'process_state',return_value=None),patch.object(m.os,'kill') as kill:
            with self.assertRaises(m.SafetyError):m.stop('central')
            kill.assert_not_called()
    def test_stop_verified_only(self):
        m.prepare_private()
        (m.pid_file('central')).write_text(json.dumps({'app':'central','pid':123,'starttime':'999','cwd':str(self.root/'central')}))
        with patch.object(m,'process_state',return_value='999'),patch.object(m.os,'readlink',return_value=str(self.root/'central')),patch.object(m.os,'kill') as kill:
            self.assertEqual(m.stop('central')['acao'],'sigterm_enviado')
            kill.assert_called_once_with(123,signal.SIGTERM)
    def test_archive_stopped_only(self):
        m.prepare_private()
        (m.pid_file('central')).write_text(json.dumps({'app':'central','pid':123,'starttime':'999','cwd':str(self.root/'central')}))
        (m.PRIVATE/'central-processo.log').write_text('previous log')
        with patch.object(m,'process_state',return_value=None),patch.object(m,'tcp_used',return_value=False):
            self.assertEqual(m.archive_stopped('central')['acao'],'registros_do_processo_parado_arquivados')
        self.assertFalse(m.pid_file('central').exists())
    def test_create_user_invalid_does_not_call_getpass(self):
        with patch.object(m,'local_realm_ready',return_value=True),patch.object(m.getpass,'getpass') as ask:
            with self.assertRaises(m.SafetyError):m.create_test_user('root')
            ask.assert_not_called()
    def test_create_user_short_password_does_not_call_network(self):
        with patch.object(m,'local_realm_ready',return_value=True),patch.object(m.sys.stdin,'isatty',return_value=True),patch.object(m.getpass,'getpass',return_value='short'),patch.object(m,'token_admin') as token:
            with self.assertRaises(m.SafetyError):m.create_test_user('teste.central')
            token.assert_not_called()
    def test_create_user_blocks_without_tty(self):
        with patch.object(m,'local_realm_ready',return_value=True),patch.object(m.sys.stdin,'isatty',return_value=False),patch.object(m.getpass,'getpass') as getpass:
            with self.assertRaises(m.SafetyError):m.create_test_user('teste.central')
            getpass.assert_not_called()
    def test_create_user_success_no_pwd_output(self):
        with patch.object(m,'local_realm_ready',return_value=True),patch.object(m.sys.stdin,'isatty',return_value=True),patch.object(m.getpass,'getpass',return_value='PasswordForTesting_123'),patch.object(m,'token_admin',return_value='temporary-token'),patch.object(m.urllib.request,'urlopen',return_value=DummyResponse()):
            result=m.create_test_user('teste.central')
            self.assertTrue(result['senha_deve_mudar_no_primeiro_login'])
            self.assertNotIn('PasswordForTesting_123',json.dumps(result))
    def test_validate_success_flags_only(self):
        def fakeget(url,*,limit=100000):
            if url.endswith('/app/api/platform/me'):return 200,json.dumps({'authenticated':False,'oidcConfigured':True}).encode(),''
            if url.endswith('/app/diagnostico/api/vendedor/me'):return 401,b'', ''
            if url.endswith('/app/auth/login'):return 302,b'',m.ISSUER+'/protocol/openid-connect/auth?state=hidden'
            return 404,b'', ''
        with patch.object(m,'check_domains',return_value={m.HOST:{'tls_valido':True},m.LOGIN:{'tls_valido':True}}),patch.object(m,'issuer_ready',return_value=True),patch.object(m,'local_realm_ready',return_value=True),patch.object(m,'url_get',side_effect=fakeget),patch.object(m,'local_get',return_value=(200,b'{"ok":true}')):
            result=m.validate()
            self.assertTrue(result['tudo_aprovado'])
            self.assertNotIn('state=hidden',json.dumps(result))
    def test_validate_incomplete_no_false_success(self):
        with patch.object(m,'check_domains',return_value={m.HOST:{'tls_valido':True},m.LOGIN:{'tls_valido':True}}),patch.object(m,'issuer_ready',return_value=False),patch.object(m,'local_realm_ready',return_value=False),patch.object(m,'url_get',side_effect=urllib.error.URLError('blocked')),patch.object(m,'local_get',side_effect=urllib.error.URLError('blocked')):
            self.assertFalse(m.validate()['tudo_aprovado'])
    def test_token_password_only_in_post_body(self):
        captured=[]
        def fakeurl(request,timeout):
            captured.append(request)
            return DummyResponse(200,b'{"access_token":"xyz"}')
        with patch.object(m.urllib.request,'urlopen',side_effect=fakeurl):
            value=m.token_admin({'KC_BOOTSTRAP_ADMIN_PASSWORD':'very_secret_for_test'})
            self.assertEqual(value,'xyz')
            self.assertNotIn('very_secret_for_test',captured[0].full_url)
            self.assertIn(b'very_secret_for_test',captured[0].data)
    def test_local_pid_token_current(self):
        token=m.process_state(os.getpid())
        self.assertTrue(str(token).isdigit())

if __name__=='__main__':
    import signal
    import urllib.error
    unittest.main()
