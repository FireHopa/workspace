# Entrega 07 - iniciar a homologacao (workspacecasadoads.com.br)

**Situacao anterior confirmada por log em 26/10/2026:** DNS dos dois subdominios resolve para 144.91.94.158, desafio ACME passou, Let's Encrypt emitiu certificado `workspace-hml` ate 24/01/2027, e Nginx recebeu somente os vhosts novos de homologacao. Os processos da Central, Diagnostic e Keycloak **ainda nao haviam sido iniciados**.

A Entrega 06 ja foi aplicada; as dependencias e o build ja foram instalados. **Nao rode `preparar --criar`, `gerar` nem os instaladores novamente.**

Este ZIP nao contem senhas, banco de dados, certificados ou arquivos de producao. Usa as configuracoes existentes em `~/plataforma-hml-entrega02`. Execute como usuario **`deploy`, sem `sudo`** e em periodo de menor uso: os novos containers e Node compartilham a CPU/RAM/disco/rede do mesmo VPS.

## 1. Somente verificar antes de qualquer inicializacao

Extraia o ZIP **em uma pasta nova**, ficando em `~/Entrega_07_Iniciar_Homologacao`, e execute:

```bash
cd ~/Entrega_07_Iniciar_Homologacao
python3 entrega07.py verificar
```

Confira os campos:

- `config_validada: true`
- Ambos os hosts: `ipv4_esperado: true` e `tls_valido: true`
- `docker.disponivel: true`
- **Para a PRIMEIRA inicializacao do Keycloak apenas:** `docker.containers: false`, `docker.volume: false` e `docker.rede: false`
- Portas `18100`, `18110`, `18120`: `false` em `portas_em_uso`

Se houver excecao ou valor inesperado, **pare e envie a saida do verificador**, nao rode os comandos de ativacao. O script nao altera o Nginx e nao recupera processos PM2.

## 2. Iniciar o Keycloak isolado - somente se a verificacao passou

```bash
python3 entrega07.py iniciar-keycloak --confirmar
```

**Mudanca real:** executa `docker compose -p casadoads_hml_oidc up -d --no-build postgres keycloak` exclusivamente na pasta privada `~/plataforma-hml-entrega02/privado/entrega03/keycloak`. Cria **novos** containers, rede Docker e volume de dados da homologacao. Nao monta nada da producao; nao altera arquivos do Nginx; nao reinicia PM2. Docker e compartilhado, portanto altera os recursos/rede do host, ainda que isolado por projeto.

**Se ja existir container/volume da HML, bloqueia** para evitar criar um novo banco sem perceber ou sobrescrever um banco anterior. Nao use `docker compose down -v` nem `docker volume rm` para contornar. Se o Docker nao estiver acessivel como `deploy`, nao use `sudo` sem revisar as permissoes primeiro.

A resposta pode dizer `issuer_publico_respondendo_agora: false` imediatamente depois de criar os containers; isso nao confirma falha definitiva. Confira o estado com:

```bash
python3 entrega07.py verificar
```

Se nao houver readiness, consulte **sem imprimir segredos**:

```bash
cd ~/plataforma-hml-entrega02/privado/entrega03/keycloak
docker compose -p casadoads_hml_oidc ps
```

Nao envie `docker compose config` completo, `.env` nem logs completos sem revisao, porque podem conter informacoes privadas.

## 3. Iniciar Central + Diagnostic, somente se Keycloak responder

Quando o verificador mostrar `keycloak_local_pronto: true` e `issuer_publico_pronto: true`, execute:

```bash
cd ~/Entrega_07_Iniciar_Homologacao
python3 entrega07.py iniciar-central --confirmar
python3 entrega07.py iniciar-diagnostic --confirmar
python3 entrega07.py validar
```

**Mudanca real:** abre 2 processos Node apenas em `127.0.0.1:18100` e `127.0.0.1:18110`. Eles nao sao cadastrados no PM2 nem no systemd e **nao reiniciam automaticamente apos reboot**. O script guarda PID+identidade do processo e log privado na pasta `~/plataforma-hml-entrega02/privado/entrega07/`. Nao apague esses arquivos durante a execucao. Nao execute `nohup` ou um segundo servidor manual em paralelo.

A validacao confere certificado TLS, issuer, API anonima da Central, rejeicao de Diagnostic sem login, saude do Diagnostic e redirecionamento de login. **O verificador de login emite uma sessao anonima somente na HML**, sem autenticar ou dar permissoes.

O resultado esperado e `"tudo_aprovado": true`. Se `false`, veja qual item falhou; nao declare a plataforma pronta para usuarios ate a validacao real.

## 4. Criar uma conta de teste - somente depois de `validar` passar

A area `/admin/` do Keycloak esta **bloqueada pelo Nginx**. O pacote oferece um metodo de criacao pela API administrativa **restrita a 127.0.0.1:18120**:

```bash
python3 entrega07.py criar-usuario --usuario teste.central --confirmar
```

Uma senha temporaria de pelo menos 14 caracteres sera pedida duas vezes, sem aparecer no historico do terminal ou na resposta JSON. **Nao utilize usuario/senha reais nem reutilize senhas de producao.** A conta nao recebe permissoes administrativas nem acesso ao Diagnostic automaticamente. A senha deve ser trocada no primeiro login.

Depois abra pelo navegador:

**https://hml.workspacecasadoads.com.br/app/**

Conclua o login de teste e a troca de senha. O painel exibira `Emissor` e `Identificador` da conta nova. **Nao envie tokens de sessao, cookies nem a senha.**

### Primeiro administrador da Central

Apenas **depois do primeiro login**, se quiser liberar uma conta de teste para gerenciar permissoes, utilize o comando original do projeto, com o `subject` exato exibido pelo proprio painel:

```bash
cd ~/plataforma-hml-entrega02/central
/home/deploy/.local/node-v24.20.0/bin/node --env-file=.env scripts/grant-admin.mjs --subject SUB_DO_USUARIO_DE_TESTE --confirm
```

**Nao invente o `subject`, nem conceda permissoes com base apenas em nome ou e-mail.** Atualize a pagina apos a concessao. O administrador ainda deve associar explicitamente um vendedor existente para habilitar o Diagnostic. Nao conecte os historicos de outro vendedor sem autorizacao.

O Diagnostic HML usa bases inicialmente vazias e **nao possui chaves de IA configuradas**; login e visualizacao podem ser testados, mas nao afirme que geracao real de diagnosticos foi validada antes de configurar recursos de teste apropriados.

## 5. Parar somente os processos Node da HML (opcional)

```bash
cd ~/Entrega_07_Iniciar_Homologacao
python3 entrega07.py parar-diagnostic --confirmar
python3 entrega07.py parar-central --confirmar
```

Somente manda SIGTERM se o PID, o horario de inicializacao do processo e a pasta de trabalho corresponderem ao registro criado por esta entrega. **Nao mexe em outros processos, PM2 ou Docker.** As bases e volumes sao preservados.

Depois de confirmar que o processo realmente saiu e a porta esta livre, arquive o registro anterior antes de iniciar novamente:

```bash
python3 entrega07.py arquivar-diagnostic --confirmar
python3 entrega07.py arquivar-central --confirmar
```

Para interromper Keycloak, **nao execute** `down -v`. Consulte o guia `docs/SEGURANCA_E_REVERSAO.md` antes de qualquer operacao Docker.

## 6. O que NAO foi feito aqui

- Nao configurou PM2 nem persistencia automatica dos processos Node.
- Nao importou usuarios antigos nem vinculou historicos automaticamente.
- Nao mudou o dominio raiz `workspacecasadoads.com.br` (Workspace atual).
- Nao migrou Bobou, CRM ou Zape.
- Nao alterou o Academy.
- Nao verificou um login real no seu VPS: isso precisa ser feito pelo navegador.
- Nao alterou DNS, Nginx, certificados, secrets ou bancos de producao.

**Seguranca:** o verificador compartilha apenas indicadores e erros controlados, nunca o segredo OIDC nem as senhas. Os logs privados e `.env` nao devem ser enviados na conversa.

**Proximo passo da implementacao:** confirmar a inicializacao do Keycloak, da Central e do Diagnostic, realizar o login da conta de teste e validar autorizacao por vendedor; apenas depois planejar integracao do Workspace.
